------------------
Linecons Icon Set
48 fully scalable vector icons with outline styles. Released specifically for Smashing Magazine.
------------------

Dear friends,

Thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com. You can freely use it for both your private and commercial projects, including software, online services, templates and themes. You may not redistribute or sell these icon set on any other website or source.

Please also link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
