<?php
error_reporting(E_ERROR | E_PARSE | E_NOTICE | E_WARNING);
	require_once('lib/init.php');
	header("Access-Control-Allow-Origin: *");

?>
<!DOCTYPE html>
<html>
<body>

<h2>Get data as JSON from a PHP file on the server.</h2>

<p id="demo"></p>

<script>

var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        myObj = JSON.parse(this.responseText);
        document.getElementById("demo").innerHTML = JSON.stringify(myObj.prices[1]["price"]);
    }
};
xmlhttp.open("GET", "getQuote.php", true);
xmlhttp.send();

</script>

</body>
</html>
